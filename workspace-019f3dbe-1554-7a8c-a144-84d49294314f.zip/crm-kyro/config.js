/* =========================================================================
   CONFIGURAÇÃO CRM KYRO
   1) Projeto em https://supabase.com
   2) Project Settings > API  ->  Project URL + anon public key
   3) DEMO_MODE true = teste rápido (sem login, banco aberto)
      DEMO_MODE false = uso real em equipe (com login por e-mail/senha)
   ========================================================================= */
const CONFIG = {
  SUPABASE_URL: 'SUA_URL_AQUI',
  SUPABASE_ANON_KEY: 'SUA_CHAVE_ANON_AQUI',
  DEMO_MODE: true,
};
