/* =========================================================================
   CRM Imobiliário — lógica em JavaScript puro
   -------------------------------------------------------------------------
   POR QUE ISSO FUNCIONA NA VERCEL:
   O JS aqui roda no NAVEGADOR. A gente NÃO escreve em arquivo do projeto
   (isso não existe no browser e não persiste na Vercel). Em vez disso,
   usamos o localStorage do próprio navegador para gravar os dados.

   ✅ Funciona: cadastro, listagem, edição, exclusão, busca, dashboard.
   ⚠️ Limite: os dados ficam SÓ neste navegador/dispositivo. Para um CRM
      real (vários corretores, dados compartilhados), troque o localStorage
      por um backend — veja o README.md (Supabase ou Vercel Functions + DB).
   ========================================================================= */

// ---------- "Banco de dados" local (substitui o arquivo JSON) ----------
const db = {
  leads: ler('crm_leads', []),
  imoveis: ler('crm_imoveis', []),
};

function ler(chave, padrao) {
  try {
    const v = localStorage.getItem(chave);
    return v ? JSON.parse(v) : padrao;
  } catch {
    return padrao;
  }
}
function salvar(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}
// Gera id único sem dependências externas
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// ---------- Troca de abas ----------
document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'dashboard') renderDashboard();
  });
});

/* ============================ LEADS ============================ */
const leadForm = document.getElementById('lead-form');
const leadTbody = document.querySelector('#lead-tabela tbody');

leadForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const id = document.getElementById('lead-id').value;
  const dados = {
    nome: document.getElementById('lead-nome').value.trim(),
    telefone: document.getElementById('lead-telefone').value.trim(),
    email: document.getElementById('lead-email').value.trim(),
    tipo: document.getElementById('lead-tipo').value,
    interesse: document.getElementById('lead-interesse').value.trim(),
    bairro: document.getElementById('lead-bairro').value.trim(),
    status: document.getElementById('lead-status').value,
    obs: document.getElementById('lead-obs').value.trim(),
    criadoEm: new Date().toISOString(),
  };
  if (id) {
    const i = db.leads.findIndex((l) => l.id === id);
    if (i > -1) db.leads[i] = { ...db.leads[i], ...dados };
  } else {
    db.leads.push({ id: uid(), ...dados });
  }
  salvar('crm_leads', db.leads);
  resetLeadForm();
  renderLeads();
});

document.getElementById('lead-cancel').addEventListener('click', resetLeadForm);
document.getElementById('lead-busca').addEventListener('input', renderLeads);

function resetLeadForm() {
  leadForm.reset();
  document.getElementById('lead-id').value = '';
  document.getElementById('lead-form-title').textContent = 'Novo Lead';
  document.getElementById('lead-cancel').hidden = true;
}

function editarLead(id) {
  const l = db.leads.find((x) => x.id === id);
  if (!l) return;
  document.getElementById('lead-id').value = l.id;
  document.getElementById('lead-nome').value = l.nome;
  document.getElementById('lead-telefone').value = l.telefone;
  document.getElementById('lead-email').value = l.email;
  document.getElementById('lead-tipo').value = l.tipo;
  document.getElementById('lead-interesse').value = l.interesse;
  document.getElementById('lead-bairro').value = l.bairro;
  document.getElementById('lead-status').value = l.status;
  document.getElementById('lead-obs').value = l.obs;
  document.getElementById('lead-form-title').textContent = 'Editar Lead';
  document.getElementById('lead-cancel').hidden = false;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function excluirLead(id) {
  if (!confirm('Excluir este lead?')) return;
  db.leads = db.leads.filter((l) => l.id !== id);
  salvar('crm_leads', db.leads);
  renderLeads();
}

function renderLeads() {
  const termo = document.getElementById('lead-busca').value.toLowerCase();
  const filtrados = db.leads.filter((l) =>
    [l.nome, l.telefone, l.bairro, l.interesse].join(' ').toLowerCase().includes(termo)
  );
  leadTbody.innerHTML = filtrados.map((l) => `
    <tr>
      <td>${esc(l.nome)}</td>
      <td>${esc(l.telefone)}</td>
      <td>${esc(l.tipo)}</td>
      <td>${esc(l.interesse)}</td>
      <td><span class="tag ${slug(l.status)}">${esc(l.status)}</span></td>
      <td><div class="row-actions">
        <button class="icon-btn edit" onclick="editarLead('${l.id}')">Editar</button>
        <button class="icon-btn del" onclick="excluirLead('${l.id}')">Excluir</button>
      </div></td>
    </tr>`).join('');
  document.getElementById('lead-vazio').style.display = filtrados.length ? 'none' : 'block';
}

/* ============================ IMÓVEIS ============================ */
const imovelForm = document.getElementById('imovel-form');
const imovelTbody = document.querySelector('#imovel-tabela tbody');

imovelForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const id = document.getElementById('imovel-id').value;
  const dados = {
    titulo: document.getElementById('imovel-titulo').value.trim(),
    tipo: document.getElementById('imovel-tipo').value,
    bairro: document.getElementById('imovel-bairro').value.trim(),
    valor: Number(document.getElementById('imovel-valor').value) || 0,
    status: document.getElementById('imovel-status').value,
  };
  if (id) {
    const i = db.imoveis.findIndex((x) => x.id === id);
    if (i > -1) db.imoveis[i] = { ...db.imoveis[i], ...dados };
  } else {
    db.imoveis.push({ id: uid(), ...dados });
  }
  salvar('crm_imoveis', db.imoveis);
  resetImovelForm();
  renderImoveis();
});

document.getElementById('imovel-cancel').addEventListener('click', resetImovelForm);
document.getElementById('imovel-busca').addEventListener('input', renderImoveis);

function resetImovelForm() {
  imovelForm.reset();
  document.getElementById('imovel-id').value = '';
  document.getElementById('imovel-form-title').textContent = 'Novo Imóvel';
  document.getElementById('imovel-cancel').hidden = true;
}

function editarImovel(id) {
  const i = db.imoveis.find((x) => x.id === id);
  if (!i) return;
  document.getElementById('imovel-id').value = i.id;
  document.getElementById('imovel-titulo').value = i.titulo;
  document.getElementById('imovel-tipo').value = i.tipo;
  document.getElementById('imovel-bairro').value = i.bairro;
  document.getElementById('imovel-valor').value = i.valor;
  document.getElementById('imovel-status').value = i.status;
  document.getElementById('imovel-form-title').textContent = 'Editar Imóvel';
  document.getElementById('imovel-cancel').hidden = false;
}

function excluirImovel(id) {
  if (!confirm('Excluir este imóvel?')) return;
  db.imoveis = db.imoveis.filter((x) => x.id !== id);
  salvar('crm_imoveis', db.imoveis);
  renderImoveis();
}

function renderImoveis() {
  const termo = document.getElementById('imovel-busca').value.toLowerCase();
  const filtrados = db.imoveis.filter((i) =>
    [i.titulo, i.bairro, i.tipo].join(' ').toLowerCase().includes(termo)
  );
  imovelTbody.innerHTML = filtrados.map((i) => `
    <tr>
      <td>${esc(i.titulo)}</td>
      <td>${esc(i.tipo)}</td>
      <td>${esc(i.bairro)}</td>
      <td>${i.valor ? 'R$ ' + i.valor.toLocaleString('pt-BR') : '—'}</td>
      <td><span class="tag ${slug(i.status)}">${esc(i.status)}</span></td>
      <td><div class="row-actions">
        <button class="icon-btn edit" onclick="editarImovel('${i.id}')">Editar</button>
        <button class="icon-btn del" onclick="excluirImovel('${i.id}')">Excluir</button>
      </div></td>
    </tr>`).join('');
  document.getElementById('imovel-vazio').style.display = filtrados.length ? 'none' : 'block';
}

/* ============================ DASHBOARD ============================ */
function renderDashboard() {
  const totalLeads = db.leads.length;
  const novos = db.leads.filter((l) => l.status === 'Novo').length;
  const negociacao = db.leads.filter((l) => l.status === 'Em negociação').length;
  const fechados = db.leads.filter((l) => l.status === 'Fechado').length;
  const totalImoveis = db.imoveis.length;
  const disponiveis = db.imoveis.filter((i) => i.status === 'Disponível').length;
  const valorTotal = db.imoveis.reduce((s, i) => s + (i.valor || 0), 0);

  const cards = [
    { num: totalLeads, lbl: 'Total de leads' },
    { num: novos, lbl: 'Leads novos' },
    { num: negociacao, lbl: 'Em negociação' },
    { num: fechados, lbl: 'Fechados' },
    { num: totalImoveis, lbl: 'Imóveis cadastrados' },
    { num: disponiveis, lbl: 'Imóveis disponíveis' },
    { num: 'R$ ' + valorTotal.toLocaleString('pt-BR'), lbl: 'Valor em carteira' },
  ];
  document.getElementById('stats').innerHTML = cards
    .map((c) => `<div class="stat"><div class="num">${c.num}</div><div class="lbl">${c.lbl}</div></div>`)
    .join('');
}

// Converte "Em negociação" -> "em-negociacao" para usar em classe CSS
function slug(t) {
  return String(t ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

// Escapa HTML para evitar que dados quebrem a página / XSS
function esc(t) {
  return String(t ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

// Primeira renderização
renderLeads();
renderImoveis();
