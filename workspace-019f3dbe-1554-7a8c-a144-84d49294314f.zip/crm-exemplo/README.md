# CRM Imobiliário — Exemplo funcional

Exemplo de CRM para imobiliária (leads + imóveis + dashboard) em **HTML/CSS/JS puro**,
que funciona de verdade quando hospedado na Vercel.

## Por que o seu CRM anterior "não gerava cadastro nem nenhuma função"

Na Vercel, o site é **estático**: o JavaScript roda no **navegador do visitante**, não num
servidor com acesso à pasta do projeto. Se o código original tentava algo assim:

```js
// ❌ ISSO NÃO FUNCIONA NO NAVEGADOR / VERCEL
const fs = require('fs');
fs.writeFile('cadastros.json', JSON.stringify(dados));   // "fs" não existe no browser

// ou
fetch('cadastros.json', { method: 'POST', body: ... });  // não há esse endpoint
```

...ele quebrava silenciosamente antes de salvar. Daí "nada funcionava".

## O que este exemplo faz diferente

Em vez de gravar num arquivo do projeto, usamos o **localStorage** do navegador:

```js
localStorage.setItem('crm_leads', JSON.stringify(leads)); // ✅ funciona no browser
const leads = JSON.parse(localStorage.getItem('crm_leads') || '[]');
```

Com isso, **cadastro, listagem, edição, exclusão, busca e dashboard funcionam** na Vercel.

> ⚠️ Limite do localStorage: os dados ficam salvos **só naquele navegador/dispositivo**.
> Não são compartilhados entre corretores e somem se o usuário limpar os dados do site.
> Serve perfeitamente para testar a aplicação e aprender o padrão correto.

## Como rodar / publicar

1. Jogue esses 3 arquivos (`index.html`, `styles.css`, `app.js`) na raiz do seu repositório.
2. Conecte o repo à Vercel (ou use `vercel` CLI). Sem build, sem configuração.
3. Pronto — abra e cadastre um lead.

## Próximo passo: dados de verdade (compartilhados)

Quando quiser que vários corretores vejam os mesmos leads, troque o `localStorage` por um
backend. A opção mais rápida é o **Supabase** (Postgres grátis + já pronto):

```js
// Exemplo: salvar lead no Supabase em vez de localStorage
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

await supabase.from('leads').insert({
  nome, telefone, email, tipo, interesse, bairro, status, obs
});
const { data } = await supabase.from('leads').select('*'); // lista os leads
```

Ou, mantendo tudo na Vercel, crie uma **Serverless Function** (`api/leads.js`) que grava num
banco real (Vercel Postgres, MongoDB Atlas, Upstash...). Aí sim o arquivo some e entra o banco.

## Estrutura

```
crm-exemplo/
├── index.html   → telas e formulários
├── styles.css   → visual
├── app.js       → lógica (cadastro/listagem/edição/exclusão/dashboard)
└── README.md    → este arquivo
```
